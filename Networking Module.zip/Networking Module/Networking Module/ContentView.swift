//
//  ContentView.swift
//  Networking Module
//
//  Created by Jaffer Sheriff U on 17/07/22.
//

import SwiftUI

struct ContentView: View {
    let requestManager : RequestManagerProtocol
    
    @State var isLoading : Bool = true
    
    init (withRequestManager reqManager : RequestManagerProtocol){
        self.requestManager = reqManager
    }
    
    var body: some View {
        ZStack{
            if isLoading{
                ProgressView()
                    .progressViewStyle(.circular)
                    .task {
                        await fetchFromAPI()
                    }
            }else{
                Text("Loding Finished")
                    .fontWeight(.bold)
            }
        }
    }
    
    func fetchFromAPI() async{
      
        do {
            let result : Welcome = try await requestManager.perform(WelcomeRequest.welcome)
            print(result)
            isLoading = false
        }catch{
            print(error)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(withRequestManager: RequestManager())
    }
}

