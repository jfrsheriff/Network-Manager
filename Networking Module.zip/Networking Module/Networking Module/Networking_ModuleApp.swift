//
//  Networking_ModuleApp.swift
//  Networking Module
//
//  Created by Jaffer Sheriff U on 17/07/22.
//

import SwiftUI

@main
struct Networking_ModuleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView(withRequestManager: RequestManager())
        }
    }
}
