//
//  APIManager.swift
//  Networking Module
//
//  Created by Jaffer Sheriff U on 17/07/22.
//

import Foundation

protocol APIManagerProtocol {
    func perform(request : APIRequestProtocol, authToken : String) async throws -> Data
    func requestToken() async throws -> Data
}

class APIManager : APIManagerProtocol{
    
    let urlSession : URLSession
    
    init(withSession session : URLSession = URLSession.shared ){
        urlSession = session
    }
    
    func perform(request : APIRequestProtocol, authToken : String = "") async throws -> Data{
        let urlReq = try request.getURLRequestWith(token: authToken)
        
        let (data, response) = try await urlSession.data(for: urlReq)
        guard let httpResponse = response as? HTTPURLResponse,
          httpResponse.statusCode == 200 else { throw NetworkError.invalidServerResponse }
        return data
    }
    
    func requestToken() async throws -> Data {
        try await perform(request: AuthorizationResource.authorization)
    }
}
