//
//  APIConstants.swift
//  Networking Module
//
//  Created by Jaffer Sheriff U on 17/07/22.
//

import Foundation

struct APIConstants {
    static let host = "jsonplaceholder.typicode.com"
    static let scheme = "https"
    
    static let grantType = "client_credentials"
    static let clientId = "YourKeyHere"
    static let clientSecret = "YourSecretHere"
}
