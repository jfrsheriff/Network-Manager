//
//  RequestType.swift
//  Networking Module
//
//  Created by Jaffer Sheriff U on 17/07/22.
//

import Foundation

enum RequestType : String{
    case POST
    case GET
    case PUT
    case DELETE
    case PATCH
}
