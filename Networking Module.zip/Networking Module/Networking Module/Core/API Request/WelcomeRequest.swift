//
//  WelcomeRequest.swift
//  Networking Module
//
//  Created by Jaffer Sheriff U on 17/07/22.
//

import Foundation

enum WelcomeRequest : APIRequestProtocol{
   
    case welcome
    
    var path: String{
        "/posts"
    }
    
    var shouldIncludeAuthenticationToken: Bool{
        false
    }
    
}
