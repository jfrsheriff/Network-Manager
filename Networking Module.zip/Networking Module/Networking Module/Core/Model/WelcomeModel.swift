//
//  WelcomeModel.swift
//  Networking Module
//
//  Created by Jaffer Sheriff U on 17/07/22.
//

import Foundation

// MARK: - WelcomeElement
struct WelcomeElement: Codable {
    let userID, id: Int
    let title, body: String

    enum CodingKeys: String, CodingKey {
        case userID = "userId"
        case id, title, body
    }
}

typealias Welcome = [WelcomeElement]
