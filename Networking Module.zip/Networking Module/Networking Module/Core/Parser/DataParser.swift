//
//  DataParser.swift
//  Networking Module
//
//  Created by Jaffer Sheriff U on 17/07/22.
//

import Foundation

protocol DataParserProtocol {
    func parse<T:Decodable>(_ data : Data) throws -> T
}

class DataParser : DataParserProtocol{
    private var decoder: JSONDecoder
    init(withDecoder decoder : JSONDecoder = JSONDecoder()){
        self.decoder = decoder
    }
    
    func parse<T>(_ data: Data) throws -> T where T : Decodable {
        let decodedValue = try decoder.decode(T.self, from: data)
        return decodedValue
    }
    
}
