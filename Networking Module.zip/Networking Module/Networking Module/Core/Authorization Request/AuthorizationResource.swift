//
//  AuthorizationResource.swift
//  Networking Module
//
//  Created by Jaffer Sheriff U on 17/07/22.
//

import Foundation


enum AuthorizationResource : APIRequestProtocol {
    
    case authorization
    
    var path : String {
        return "/v2/oauth2/token"
    }
    

    var requestParam: [String : Any] {
        [
            "grant_type": APIConstants.grantType,
            "client_id": APIConstants.clientId,
            "client_secret": APIConstants.clientSecret
        ]
    }
    
    var shouldIncludeAuthenticationToken : Bool {
        false
    }
    
    var requestType : RequestType {
        .POST
    }
    
}

